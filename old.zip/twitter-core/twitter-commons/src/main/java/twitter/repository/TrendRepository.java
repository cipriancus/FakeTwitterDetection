package twitter.repository;

import twitter.entity.Trend;

public interface TrendRepository extends AbstractSocialNetworkRepository<Trend> {


}
