package twitter.repository;


import twitter.entity.Tweet;

public interface TweetRepository extends AbstractSocialNetworkRepository<Tweet> {
}
