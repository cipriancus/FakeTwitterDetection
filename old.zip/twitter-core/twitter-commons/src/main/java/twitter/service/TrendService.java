package twitter.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import twitter.entity.Trend;
import twitter.repository.TrendRepository;

import java.util.List;


@Service
@Transactional(propagation = Propagation.REQUIRES_NEW)
public class TrendService {

    @Autowired
    private TrendRepository trendRepository;

    public Trend save(Trend trend) {
        return trendRepository.save(trend);
    }

    public List<Trend> findAll(Trend trend) {
        return trendRepository.findAll();
    }


}
