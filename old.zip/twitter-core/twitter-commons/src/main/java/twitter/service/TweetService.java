package twitter.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import twitter.entity.Tweet;
import twitter.repository.TweetRepository;

import java.util.List;

@Service
@Transactional(propagation = Propagation.REQUIRES_NEW)
public class TweetService {
    @Autowired
    private TweetRepository tweetRepository;

    public Tweet save(Tweet tweet) {
        return tweetRepository.save(tweet);
    }

    public List<Tweet> findAll() { return tweetRepository.findAll();}
}
