package twitter.login.exception;

public class EmptyArgumentException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public EmptyArgumentException() {
		// TODO Auto-generated constructor stub
		super("Call parameters empty, please provide correct input");
	}
}
