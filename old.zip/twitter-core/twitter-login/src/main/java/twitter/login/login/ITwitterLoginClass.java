package twitter.login.login;

import twitter4j.auth.AccessToken;

public interface ITwitterLoginClass {
	public void setKey(String consumerKey,String secretKey);
	public String getToken();
	public String getTokenSecret();
	public String getAuthorizationURL();
	public boolean login(String authCode);
	public AccessToken getAccessToken();
}
