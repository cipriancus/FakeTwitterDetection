package twitter.login.login.impl;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import twitter.login.exception.EmptyArgumentException;
import twitter.login.login.ITwitterLoginClass;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.auth.AccessToken;
import twitter4j.auth.RequestToken;
import twitter4j.conf.ConfigurationBuilder;

public class TwitterLoginClass implements ITwitterLoginClass {

    private String consumerKey;
    private String consumerSecret;
    private String token;
    private ConfigurationBuilder cb;
    private TwitterFactory tf;
    private RequestToken requestToken;
    private Twitter twitter;
    private AccessToken accessToken = null;

    public TwitterLoginClass() {

    }

    public TwitterLoginClass(String consumerKey, String secretKey) throws EmptyArgumentException {
        construct(consumerKey, secretKey);
    }

    public void construct(String consumerKey, String secretKey) throws EmptyArgumentException {
        if (consumerKey.length() == 0 || secretKey.length() == 0)
            throw new EmptyArgumentException();

        cb = new ConfigurationBuilder();
        cb.setDebugEnabled(true).setOAuthConsumerKey(consumerKey).setOAuthConsumerSecret(secretKey)
                .setOAuthAccessToken(null).setOAuthAccessTokenSecret(null);
        tf = new TwitterFactory(cb.build());
        twitter = tf.getInstance();
    }

    public void setKey(String consumerKey, String secretKey) {
        // TODO Auto-generated method stub
        this.consumerKey = consumerKey;
        this.consumerSecret = secretKey;
    }

    public String getToken() {
        try {
            requestToken = twitter.getOAuthRequestToken();
            return requestToken.getToken();
        } catch (Exception e) {
            return "Failed";
        }
    }

    public AccessToken getAccessToken(){
        return accessToken;
    }

    public String getTokenSecret() {
        return requestToken.getTokenSecret();
    }

    public String getAuthorizationURL() {
        return requestToken.getAuthorizationURL();
    }

    public RequestToken getOAuthRequestToken() {
        try {
            return twitter.getOAuthRequestToken();
        } catch (Exception e) {
            return null;
        }
    }

    public AccessToken getOAuthAccessToken(RequestToken requestToken, String pin) {
        try {
            return twitter.getOAuthAccessToken(requestToken, pin);
        } catch (TwitterException te) {
            if (401 == te.getStatusCode()) {
                System.out.println("Unable to get the access token.");
            } else {
                te.printStackTrace();
            }
            return null;
        }
    }

    public boolean login(String authCode) {
        try {
            accessToken = getOAuthAccessToken(requestToken, authCode);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
