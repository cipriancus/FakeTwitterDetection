//package test;
//
//import static org.junit.Assert.assertTrue;
//
//import org.junit.Ignore;
//import org.junit.Test;
//
//import twitter.login.exception.EmptyArgumentException;
//import twitter.login.login.ILoginClass;
//import twitter.login.login.TwitterLoginClass;
//
//@Ignore
//public class ILoginTest {
//
//	ILoginClass twitterLogin;
//
//	//@Test
//	@Ignore("Enable only at big test")
//	public void loginTwitterPass() throws EmptyArgumentException{
//		twitterLogin=new TwitterLoginClass("OFaoKp7IxZOCIXYdx9pImfTS8", "ihC8W3Dyi5XRoS0yiPs3O5ab0sty5L1G3WR7WZ2PD7Yx7MAyWq");
//		assertTrue(twitterLogin.login());
//	}
//
//	@Test(expected=EmptyArgumentException.class)
//	public void loginClassThrowException() throws EmptyArgumentException {
//		twitterLogin=new TwitterLoginClass("", "");
//	}
//
//	@Test
//	public void getTokenTest() throws EmptyArgumentException {
//		twitterLogin=new TwitterLoginClass("OFaoKp7IxZOCIXYdx9pImfTS8", "ihC8W3Dyi5XRoS0yiPs3O5ab0sty5L1G3WR7WZ2PD7Yx7MAyWq");
//		assertTrue(twitterLogin.getToken().length()>0);
//	}
//}
