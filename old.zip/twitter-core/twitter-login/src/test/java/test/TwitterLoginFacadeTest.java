//package test;
//
//import static org.junit.Assert.assertTrue;
//
//import org.junit.Ignore;
//import org.junit.Test;
//
//import twitter.login.exception.EmptyArgumentException;
//import twitter.login.login.TwitterLoginFacade;
//
//@Ignore
//public class TwitterLoginFacadeTest {
//
//	//@Test
//	@Ignore("Enable only at big test")
//	public void loginClassReturnTrue() throws EmptyArgumentException {
//		TwitterLoginFacade twitterLoginFacade =new TwitterLoginFacade();
//		assertTrue(twitterLoginFacade.login("OFaoKp7IxZOCIXYdx9pImfTS8", "ihC8W3Dyi5XRoS0yiPs3O5ab0sty5L1G3WR7WZ2PD7Yx7MAyWq"));
//	}
//
//	@Test(expected=EmptyArgumentException.class)
//	public void loginClassThrowException() throws EmptyArgumentException {
//    	TwitterLoginFacade twitterLoginFacade =new TwitterLoginFacade();
//    	twitterLoginFacade.login("", "");
//	}
//}
