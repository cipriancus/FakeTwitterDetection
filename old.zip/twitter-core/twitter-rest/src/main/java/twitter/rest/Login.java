package twitter.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.social.twitter.api.Tweet;
import org.springframework.stereotype.Component;
import twitter.exception.InvalidInputException;
import twitter.login.login.ITwitterLoginClass;
import twitter.session.SessionBean;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Component
@Path("/security")
public class Login {

    @Autowired
    SessionBean sessionBean;

    @Autowired
    ITwitterLoginClass loginClass;

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/login")
    public String login() {
        if (sessionBean.isLogged() == true) {
            return "You are already logged in";
        } else {
            String url = loginClass.getAuthorizationURL();//send auth url
            sessionBean.setAuthorizationURL(url);
            return url;
        }
    }

    @POST
    @Path("/authorize")
    public Response authorize(@QueryParam("authorizationUrl") String authorizationUrl, @QueryParam("authorizationCode") String authorizationCode) {
        if (authorizationUrl.equals(sessionBean.getAuthorizationURL()) == true) {
            boolean logged=loginClass.login(authorizationUrl);
            if(logged==false){
                sessionBean.setAccessToken(loginClass.getAccessToken());
                return Response.status(Response.Status.UNAUTHORIZED).entity("Failed to login").build();
            }
            return Response.status(Response.Status.OK).entity("You are now logged in").build();
        }else{
            return Response.status(Response.Status.BAD_REQUEST).entity("Authorization url is not valid").build();
        }
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/logout")
    public String logout() {
        if (sessionBean.isLogged() == true) {
            sessionBean.logout();
            return "You have been logged out";
        }
        return "You are not logged in";
    }
}
