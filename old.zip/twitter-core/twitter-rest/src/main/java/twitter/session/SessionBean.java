package twitter.session;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.social.twitter.api.TwitterProfile;
import org.springframework.stereotype.Component;
import twitter4j.auth.AccessToken;

@Component
@Scope(value = "session", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class SessionBean {

    private AccessToken accessToken;

    private String authorizationURL;

    private boolean logged;

    public SessionBean() {
        logged = false;
    }

    public void setAuthorizationURL(String authorizationURL) {
        this.authorizationURL = authorizationURL;
    }

    public String getAuthorizationURL() {
        return authorizationURL;
    }

    public boolean isLogged() {
        return logged;
    }

    public void setAccessToken(AccessToken accessToken) {
        this.logged=true;
        this.accessToken = accessToken;
    }

    public AccessToken getAccessToken() {
        return accessToken;
    }

    public void logout() {
        logged = false;
        authorizationURL = null;
    }
}
