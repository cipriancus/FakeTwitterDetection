package twitter.scrape;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.social.twitter.api.Tweet;
import org.springframework.social.twitter.api.impl.TwitterTemplate;
import org.springframework.stereotype.Component;
import twitter.exception.InvalidInputException;
import twitter.service.TweetService;
import javax.annotation.PostConstruct;
import java.util.List;

@Component
public class TwitterScrape {
    @Autowired
    private TweetService tweetService;

    @Autowired
    private TwitterTemplate twitterTemplate;

    public List<Tweet> scrape(String term) throws InvalidInputException{
        if(term == null || term.length()==0)
            throw new InvalidInputException();

        List<Tweet> tweetList = twitterTemplate.searchOperations().search(term).getTweets();

        tweetList.forEach(tweetEntity -> {
            twitter.entity.Tweet tweet = new twitter.entity.Tweet();
            tweet.setText(tweetEntity.getText());
            tweetService.save(tweet);
        });
        return tweetList;
    }
}
