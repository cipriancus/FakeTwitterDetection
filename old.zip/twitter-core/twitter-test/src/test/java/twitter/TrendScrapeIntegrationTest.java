package twitter;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.social.twitter.api.Trend;
import org.springframework.social.twitter.api.Tweet;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import twitter.exception.InvalidInputException;
import twitter.scrape.TwitterScrape;
import twitter.trend.TrendSearch;
import static org.junit.Assert.assertNotNull;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:META-INF/twitter/applicationContext.xml",
        "classpath:META-INF/twitter/main/applicationContext.xml",
        "classpath:META-INF/twitter/trend/applicationContext.xml",
        "classpath:META-INF/twitter/scrape/applicationContext.xml",
        "classpath:META-INF/twitter/nlp/applicationContext.xml"})
@Ignore
public class TrendScrapeIntegrationTest {
    @Autowired
    private TrendSearch trendSearch;

    @Autowired
    private TwitterScrape twitterScrape;

    private final int WORLD_WOEID = 1;

    @Test
    public final void trendSearchAndScrape() throws InvalidInputException {
        List<Trend> trends = trendSearch.getTrends(WORLD_WOEID).subList(0, 5);//get some trends
        assertNotNull(trends);
        for (Trend trend : trends) {
            List<Tweet> tweets = twitterScrape.scrape(trend.getName()).subList(0, 5);
            assertNotNull(tweets);
        }
    }
}
