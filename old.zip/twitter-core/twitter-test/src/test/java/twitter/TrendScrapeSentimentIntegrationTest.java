package twitter;

import org.junit.Ignore;
import twitter.nlp.service.IParseFacade;
import twitter.nlp.service.ISentiment;
import twitter.nlp.service.impl.Lemmatize;
import twitter.nlp.service.impl.Tokenizer;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.social.twitter.api.Trend;
import org.springframework.social.twitter.api.Tweet;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import twitter.exception.InvalidInputException;
import twitter.scrape.TwitterScrape;
import twitter.trend.TrendSearch;

import java.util.List;

import static org.junit.Assert.assertNotNull;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:META-INF/twitter/applicationContext.xml",
        "classpath:META-INF/twitter/main/applicationContext.xml",
        "classpath:META-INF/twitter/trend/applicationContext.xml",
        "classpath:META-INF/twitter/scrape/applicationContext.xml",
        "classpath:META-INF/twitter/nlp/applicationContext.xml"})
@Ignore
public class TrendScrapeSentimentIntegrationTest {
    @Autowired
    private TrendSearch trendSearch;

    @Autowired
    private TwitterScrape twitterScrape;

    @Autowired
    private ISentiment sentimentAnalysis;

    private IParseFacade lemmatize = new Lemmatize();

    private IParseFacade tokenize = new Tokenizer();

    private final int WORLD_WOEID = 1;

    @Test
    public final void trendSearchAndScrapeWithSentiment() {
        List<Trend> trends = trendSearch.getTrends(WORLD_WOEID).subList(0, 10);
        assertNotNull(trends);
        trends.forEach(
                trend -> {
                    try {
                        List<Tweet> tweets = twitterScrape.scrape(trend.getName()).subList(0, 10);
                        assertNotNull(tweets);
                        tweets.forEach(
                                tweet -> {
                                    try {
                                        int sentiment = sentimentAnalysis.calculateSentiment(tweet.getText());
                                        assert (sentiment >= 0);
                                    } catch (
                                            InvalidInputException e
                                            ) {
                                        e.printStackTrace();
                                    }
                                }
                        );
                    } catch (
                            InvalidInputException e
                            ) {
                        e.printStackTrace();
                    } catch (org.springframework.web.client.HttpClientErrorException e){

                    }
                }
        );
    }

    @Test
    public final void trendSearchAndScrapeWithLematize() {
        List<Trend> trends = trendSearch.getTrends(WORLD_WOEID).subList(0, 10);
        assertNotNull(trends);
        trends.forEach(
                trend -> {
                    try {
                        List<Tweet> tweets = twitterScrape.scrape(trend.getName()).subList(0, 10);
                        assertNotNull(tweets);
                        tweets.forEach(
                                tweet -> {
                                    try {
                                        List<String> result = (List<String>) lemmatize.getResult(tweet.getText());
                                        assert (result.size() > 0);
                                    } catch (
                                            InvalidInputException e
                                            ) {
                                        e.printStackTrace();
                                    }
                                }
                        );
                    } catch (
                            InvalidInputException e
                            ) {
                        e.printStackTrace();
                    }
                }
        );
    }

    @Test
    public final void trendSearchAndScrapeWithTokenize() {
        List<Trend> trends = trendSearch.getTrends(WORLD_WOEID).subList(0, 10);
        assertNotNull(trends);
        trends.forEach(
                trend -> {
                    try {
                        List<Tweet> tweets = twitterScrape.scrape(trend.getName()).subList(0, 10);
                        assertNotNull(tweets);
                        tweets.forEach(
                                tweet -> {
                                    try {
                                        List<String> result = (List<String>) tokenize.getResult(tweet.getText());
                                        assert (result.size() > 0);
                                    } catch (
                                            InvalidInputException e
                                            ) {
                                        e.printStackTrace();
                                    }
                                }
                        );
                    } catch (
                            InvalidInputException e
                            ) {
                        e.printStackTrace();
                    }
                }
        );
    }

    @Test(expected = InvalidInputException.class)
    public final void trendSearchAndScrapeWithSentiment_tweetIsNull_ShouldThrowException() throws InvalidInputException {
        List<Trend> trends = trendSearch.getTrends(WORLD_WOEID).subList(0, 10);
        assertNotNull(trends);
        for (Trend trend : trends) {
            List<Tweet> tweets = twitterScrape.scrape(trend.getName()).subList(0, 10);
            assertNotNull(tweets);

            for (Tweet tweet : tweets) {
                int sentiment = sentimentAnalysis.calculateSentiment(null);
            }

        }
    }
}